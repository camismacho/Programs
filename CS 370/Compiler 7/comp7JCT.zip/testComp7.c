int y;
main(int argc, char* argv)
{
   y = 0;
   do {
       puts("do while loop m8\n");
       y = y + 1;
   } while (y < 10);

}
