func()
{
   puts("hello world!");
}

main()
{
   func("goodbye","second",42);
   printf("printf call %s %d\n","and more",42+4+5+2);
   puts("Hello World!");
}
