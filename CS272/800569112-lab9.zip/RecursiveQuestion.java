public class RecursiveQuestion {
	
	/**
	 * @author Joseph Camacho-Terrazas
	 * @param k
	 * @precondition
	 * 	k is greater than 2
	 * @postcondition
	 * 	the fibonacci sum is returned
	 * @return k
	 */

	public static int FibBinaryRecursive(int k) {
		
		if (k < 2) return k;
		
		return FibBinaryRecursive(k - 1) + FibBinaryRecursive(k - 2);
	}
	
	/**
	 * @author Joseph Camacho-Terrazas
	 * @param num source destination temp
	 * @precondition
	 * 	num is greater than 0
	 * @postcondition
	 * 	the function tells you how to solve the towers of hanoi puzzle
	 */

	 public static void HanoiTower(int num, int source, int destination, int temp) {
		 
		 if (num <= 0) return;
		    
		    HanoiTower(num - 1, source, temp, destination);
		    System.out.println("Move plate " + num + " from pole " + source + " to pole " + destination + ".");
		    HanoiTower(num - 1, temp, destination, source);
		 }

	/**
	 * @author Joseph Camacho-Terrazas
	 * @param L curl
	 * @postcondition
	 * 	prints out a statement showing the recursion level
	 * @return output
	 */

	 public static String showCallLevel(int L, int curl) {
		 
		 //keeps track of indents
		 String tab = "";
		 for (int i = 0; i < curl - 1; i++) {tab += "\t";}
		 
		 System.out.println(tab + "This was written by call number " + curl + "x");
		 if (L == 1) return "1";
		 
		 String output = showCallLevel(L - 1, curl + 1);
		 System.out.println(tab + "This was written by call number " + curl + "y");
		 return output + " + 1";
		
	 }
	
	 /**
	 * @author Joseph Camacho-Terrazas
	 * @param n
	 * @precondition
	 * 	n is greater than 0
	 * @postcondition
	 * 	prints out n in binary
	 */


	 public static void BinaryPrint(int n) { 
		 
		 if (n <= 0) return;
		 	
		 BinaryPrint(n / 2);
		 System.out.print(n % 2);
	        
	    }

	 /**
	 * @author Joseph Camacho-Terrazas
	 * @param outs n i
	 * @postcondition
	 * 	prints out the fractal pattern
	 */


	 public static String fractal(String output, int a, int b) {
		 
	     int num = (int)(Math.log(a) / Math.log(2));    
	    
	     if (num == 0) {
	    	 
	    	 for (int i = 0; i < b; i++) {output += ' ';}
	         for (int i = 0; i < a; i++) {output += "* ";}
	         
	         return output+= '\n';   
	         }
	     
	     else {
	    	 
	    	 output = fractal(output, (int)(Math.pow(2.0, num - 1)), b);
	    	 
	    	 for (int i = 0; i < b; i++) {output += ' ';}
	         for (int i = 0; i < a; i++) {output += "* ";} 
	         
	         output+= '\n'; 
	         b+= num * 2;
	         
	         return output = fractal(output, (int)(Math.pow(2.0, num - 1)), b);  
	         }
	 }
	 
	 /**
	 * @author Joseph Camacho-Terrazas
	 * @postcondition
	 * 	prints out the permutations of the arrays
	 */
	 
	 public static void permutation() {
		 
	 }

	 

	public static void main(String[] args) {
		
		System.out.println("FibBinaryRecursive");
		System.out.println(FibBinaryRecursive(4));
		System.out.println("\nHanoiTower");
		HanoiTower(3,1,3,2);
		System.out.println("\nshowCallLevel");
		showCallLevel(4,1);
		System.out.println("\nBinaryPrint");
		BinaryPrint(27);
		System.out.println("\n\nFractal");
		System.out.println(fractal("",8,4));
	}

}
