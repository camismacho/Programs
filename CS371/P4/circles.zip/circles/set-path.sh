export CLASSPATH=.:/home/jcook/lib/junit-4.12.jar:/home/jcook/lib/hamcrest-core-1.3.jar
