
public class Point
{
   double x;
   double y;
}

